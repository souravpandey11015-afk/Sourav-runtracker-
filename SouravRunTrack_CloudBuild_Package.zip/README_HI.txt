SOURAV RUNTRACK - ANDROID PROJECT

Yeh Android Studio source project hai, ready-made APK nahi.

APK banane ke liye:
1. Computer par Android Studio install karo.
2. Is ZIP ko extract karo.
3. Android Studio > Open > extracted SouravRunTrackAndroid folder.
4. Gradle sync complete hone do (internet required).
5. Phone ko USB se connect karo; Developer Options aur USB debugging enable karo.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK app/build/outputs/apk/debug/app-debug.apk par milega.

GPS:
- Run start karte waqt location permission allow karo.
- Android 13+ par notification permission allow karo.
- GPS ko open sky ke neeche kuch waqt lag sakta hai.
- Android battery saver/background restrictions GPS ko rok sakte hain.
- Location data is starter project mein phone par hi rakha jata hai; koi server upload nahi hota.

IMPORTANT:
- Yeh starter Android Studio project hai, compiled/signed release APK nahi.
- GPS accuracy phone, weather, buildings aur location permission par depend karti hai.
- Calories are rough estimates.
- Pause/Resume button tracking service ko pause/resume karta hai.
- Finish Run service ko stop karta hai; history screen abhi basic starter build mein include nahi hai.

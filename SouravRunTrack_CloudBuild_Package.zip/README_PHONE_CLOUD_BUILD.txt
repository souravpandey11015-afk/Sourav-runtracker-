SOURAV RUNTRACK - PHONE-ONLY CLOUD APK BUILD

This is an Android Studio source project with a GitHub Actions workflow.
It is NOT yet a compiled APK.

WHAT THE WORKFLOW DOES
- Builds a debug APK in GitHub-hosted cloud runner using Java 17 and Gradle 8.9.
- Uploads app-debug.apk as a workflow artifact.
- Uses the official Gradle setup action and GitHub artifact upload action.

PHONE STEPS
1. Sign in to GitHub in your phone browser.
2. Create a NEW repository named SouravRunTrack. A private repository is fine.
3. Upload the CONTENTS of this ZIP into the repository root (not the outer ZIP itself).
   Make sure the .github/workflows/build-apk.yml file is included.
4. Open the repository's Actions tab.
5. Select "Build Sourav RunTrack APK" and tap "Run workflow".
   A push to main should also trigger a build automatically.
6. Open the completed workflow run and download the artifact named
   Sourav-RunTrack-debug-apk. Extract the downloaded artifact ZIP to get app-debug.apk.
7. On your phone, open the APK and follow Android's install prompt. Only install APKs
   from a repository and build you control and trust.

IMPORTANT LIMITATIONS
- The cloud build is not started by this ZIP alone. It starts after you upload the project
  to your own GitHub repository and run the workflow.
- The APK is a DEBUG build for testing, not a Play Store release.
- Current starter app has GPS live tracking, timer, distance, pace, speed and estimated
  calories. It does not yet include a persistent multi-run history or a real map display.
- Location permission and notifications are requested as needed. GPS accuracy varies.
- Do not share your GitHub password or verification codes in chat.

package com.sourav.runtrack

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var distance: TextView
    private lateinit var timer: TextView
    private lateinit var pace: TextView
    private lateinit var speed: TextView
    private lateinit var calories: TextView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("runtrack", MODE_PRIVATE) }

    private val refresh = object : Runnable {
        override fun run() {
            val metres = prefs.getFloat("distance_m", 0f).toDouble()
            val seconds = prefs.getLong("elapsed_s", 0L)
            val km = metres / 1000.0
            val paceSeconds = if (km > 0.0) (seconds / km).toInt() else 0
            distance.text = String.format("%.2f km", km)
            timer.text = formatTime(seconds)
            pace.text = if (paceSeconds > 0) String.format("%d:%02d /km", paceSeconds / 60, paceSeconds % 60) else "--:-- /km"
            speed.text = if (seconds > 0) String.format("%.1f km/h", km / seconds * 3600) else "0.0 km/h"
            calories.text = "${(km * 65).toInt()} kcal*"
            val active = prefs.getBoolean("active", false)
            status.text = if (active) "● RUNNING — GPS ACTIVE" else "● READY"
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handler.post(refresh)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(0xFF0B1020.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFF4F7FF.toInt(), bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(4, 10, 4, 10)
            }
        root.addView(label("SOURAV RUNTRACK", 25f, 0xFF55A5FF.toInt(), true))
        root.addView(label("Your personal running companion", 13f, 0xFF91A0B9.toInt()))
        status = label("● READY", 13f, 0xFF55A5FF.toInt(), true)
        root.addView(status)
        distance = label("0.00 km", 48f, 0xFFFFFFFF.toInt(), true); root.addView(distance)
        root.addView(label("TOTAL DISTANCE", 11f, 0xFF91A0B9.toInt()))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        timer = label("00:00:00", 25f, 0xFFFFFFFF.toInt(), true)
        pace = label("--:-- /km", 22f, 0xFFFFFFFF.toInt(), true)
        speed = label("0.0 km/h", 22f, 0xFFFFFFFF.toInt(), true)
        calories = label("0 kcal*", 22f, 0xFFFFFFFF.toInt(), true)
        grid.addView(label("TIME", 11f, 0xFF91A0B9.toInt())); grid.addView(timer)
        grid.addView(label("AVERAGE PACE", 11f, 0xFF91A0B9.toInt())); grid.addView(pace)
        grid.addView(label("SPEED", 11f, 0xFF91A0B9.toInt())); grid.addView(speed)
        grid.addView(label("ESTIMATED CALORIES", 11f, 0xFF91A0B9.toInt())); grid.addView(calories)
        root.addView(grid)
        val start = Button(this).apply { text = "▶  START RUN"; setOnClickListener { requestAndStart() } }
        val pause = Button(this).apply { text = "Ⅱ  PAUSE / RESUME"; setOnClickListener {
            val i = Intent(this@MainActivity, TrackingService::class.java).setAction(TrackingService.ACTION_TOGGLE)
            startService(i)
        } }
        val finish = Button(this).apply { text = "■  FINISH RUN"; setOnClickListener {
            stopService(Intent(this@MainActivity, TrackingService::class.java))
            prefs.edit().putBoolean("active", false).apply()
            Toast.makeText(this@MainActivity, "Run finished. Summary remains on screen.", Toast.LENGTH_LONG).show()
        } }
        root.addView(start); root.addView(pause); root.addView(finish)
        root.addView(label("Keep location permission enabled while running. GPS accuracy depends on your phone and surroundings.", 12f, 0xFF91A0B9.toInt()))
        root.addView(label("*Calories are a rough estimate, not a medical measurement.", 11f, 0xFF91A0B9.toInt()))
        setContentView(root)
    }

    private fun requestAndStart() {
        val permissions = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(permissions, 101)
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
            return
        }
        startTracking()
    }

    private fun startTracking() {
        val intent = Intent(this, TrackingService::class.java).setAction(TrackingService.ACTION_START)
        startForegroundService(intent)
        Toast.makeText(this, "GPS run started", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 101 && results.isNotEmpty() && results.any { it == PackageManager.PERMISSION_GRANTED }) {
            requestAndStart()
        } else if (requestCode == 102) {
            startTracking()
        } else {
            Toast.makeText(this, "Location permission is needed for GPS tracking.", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatTime(s: Long): String = String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    override fun onDestroy() { handler.removeCallbacks(refresh); super.onDestroy() }
}

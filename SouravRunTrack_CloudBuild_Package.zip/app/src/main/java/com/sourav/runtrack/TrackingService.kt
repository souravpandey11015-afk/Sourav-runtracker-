package com.sourav.runtrack

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock

class TrackingService : Service(), LocationListener {
    private lateinit var locationManager: LocationManager
    private val prefs by lazy { getSharedPreferences("runtrack", Context.MODE_PRIVATE) }
    private var lastLocation: Location? = null
    private var distanceM = 0f
    private var startElapsed = 0L
    private var pausedAt = 0L
    private var accumulatedPause = 0L
    private var paused = false

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin()
            ACTION_TOGGLE -> togglePause()
            else -> if (!prefs.getBoolean("active", false)) stopSelf()
        }
        return START_STICKY
    }

    private fun begin() {
        distanceM = 0f
        lastLocation = null
        startElapsed = SystemClock.elapsedRealtime()
        accumulatedPause = 0L
        paused = false
        prefs.edit().putBoolean("active", true).putFloat("distance_m", 0f).putLong("elapsed_s", 0L).apply()
        startForeground(11, notification("GPS tracking is active"))
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return
        }
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, this)
        } catch (_: SecurityException) { stopSelf() }
    }

    private fun togglePause() {
        if (!prefs.getBoolean("active", false)) return
        if (!paused) {
            paused = true
            pausedAt = SystemClock.elapsedRealtime()
            locationManager.removeUpdates(this)
            lastLocation = null
            updateStats()
            updateNotification("Run paused")
        } else {
            accumulatedPause += SystemClock.elapsedRealtime() - pausedAt
            paused = false
            lastLocation = null
            try { locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 1f, this) }
            catch (_: SecurityException) { stopSelf() }
            updateNotification("GPS tracking is active")
        }
    }

    override fun onLocationChanged(location: Location) {
        if (paused || location.accuracy > 35f) return
        val previous = lastLocation
        if (previous != null) {
            val d = previous.distanceTo(location)
            val dt = (location.time - previous.time).coerceAtLeast(1L) / 1000f
            if (d >= 3f && d / dt < 8f) distanceM += d
        }
        lastLocation = location
        updateStats()
    }

    private fun updateStats() {
        val now = SystemClock.elapsedRealtime()
        val elapsed = if (paused) pausedAt - startElapsed - accumulatedPause else now - startElapsed - accumulatedPause
        prefs.edit().putFloat("distance_m", distanceM).putLong("elapsed_s", (elapsed.coerceAtLeast(0L) / 1000L)).apply()
        updateNotification(String.format("%.2f km • %02d:%02d", distanceM / 1000f, elapsed / 60000, (elapsed / 1000) % 60))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Run tracking", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Sourav RunTrack").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(11, notification(text))
    }

    override fun onDestroy() {
        locationManager.removeUpdates(this)
        prefs.edit().putBoolean("active", false).apply()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.sourav.runtrack.START"
        const val ACTION_TOGGLE = "com.sourav.runtrack.TOGGLE"
        const val CHANNEL = "sourav_run_tracking"
    }
}
